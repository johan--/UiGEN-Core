<?php 
        $uigen_sidebars = array(
            // ----------------------------------------------------------------------------
            /*'sidebar1' => array(
                'name'          => __( 'Sidebar left', 'theme_text_domain' ),
                'id'            => 'left',
                'description'   => '',
                'class'         => '',
                'before_widget' => '',
                'after_widget'  => '</div>',
                'before_title'  => '<header class="entry-header"><h1 class="entry-title">',
                'after_title'   => '</h1></header><div class="entry-content">' ),
            // ----------------------------------------------------------------------------
            'sidebar2' => array(
                'name'          => __( 'Sidebar right', 'theme_text_domain' ),
                'id'            => 'right',
                'description'   => '',
                'class'         => '',
                'before_widget' => '',
                'after_widget'  => '</div>',
                'before_title'  => '<header class="entry-header"><h1 class="entry-title">',
                'after_title'   => '</h1></header><div class="entry-content">' ),
             // ----------------------------------------------------------------------------
            */
        );      
?>